import java.io.File;
import java.util.HashMap;
import java.util.HashSet;

public class Main {
	public static void main(String[] args) {
		File cities = new File("cities.txt");
		File roads = new File("roads.txt");
		Graph graph = new Graph(cities, roads);	
		HashMap<Ville,HashSet<Route>> listeAdjacence= graph.toListeDAdjacence();		
		System.out.println(listeAdjacence.size());
		System.out.println("-------------------");
		graph.bfs("Brussels");
		
	}

}
